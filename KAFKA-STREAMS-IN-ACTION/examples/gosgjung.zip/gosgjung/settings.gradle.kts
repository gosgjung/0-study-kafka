rootProject.name = "gosgjung"
